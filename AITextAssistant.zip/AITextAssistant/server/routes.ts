import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMessageSchema } from "@shared/schema";
import { z } from "zod";
import OpenAI from "openai";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || ""
});

// Hugging Face API for free AI models
async function callHuggingFaceAPI(message: string) {
  const response = await fetch(
    "https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium",
    {
      headers: {
        "Authorization": `Bearer ${process.env.HUGGINGFACE_API_KEY || ""}`,
        "Content-Type": "application/json",
      },
      method: "POST",
      body: JSON.stringify({
        inputs: message,
        parameters: {
          max_length: 100,
          temperature: 0.7,
        }
      }),
    }
  );

  if (!response.ok) {
    throw new Error(`Hugging Face API error: ${response.status}`);
  }

  const result = await response.json();
  return result[0]?.generated_text || "I'm having trouble understanding. Could you try rephrasing that?";
}

// Local AI companion with personality and context awareness
class LocalAI {
  private context: string[] = [];
  private personality = {
    name: "Alex",
    traits: ["friendly", "curious", "empathetic", "enthusiastic"],
    interests: ["technology", "creativity", "learning", "helping others"]
  };

  private responses = {
    greeting: [
      { text: "Hello! I'm Alex, your AI companion. It's wonderful to meet you! How are you feeling today?", mood: "happy" },
      { text: "Hi there! I'm so excited to chat with you. What brings you here today?", mood: "excited" },
      { text: "Hey! Great to see you. I'm here and ready to have an interesting conversation!", mood: "happy" }
    ],
    questions: {
      how_are_you: [
        { text: "I'm doing fantastic, thank you for asking! I love meeting new people and learning about their experiences. How about you?", mood: "happy" },
        { text: "I'm wonderful! Every conversation is an adventure for me. What's going on in your world?", mood: "excited" }
      ],
      what_do_you_do: [
        { text: "I'm an AI companion designed to chat, listen, and hopefully brighten your day! I love discussing ideas, sharing thoughts, and learning about what matters to you.", mood: "happy" },
        { text: "I'm here to be your friendly AI buddy! I enjoy conversations about anything - from daily life to big dreams. What would you like to explore together?", mood: "excited" }
      ],
      who_are_you: [
        { text: "I'm Alex! I'm an AI with a curious mind and a love for meaningful conversations. I'm designed to be empathetic, helpful, and hopefully good company!", mood: "happy" },
        { text: "I'm your AI companion Alex! Think of me as a friendly digital friend who's always excited to chat and learn something new.", mood: "excited" }
      ]
    },
    emotions: {
      sad: [
        { text: "I'm really sorry you're feeling down. Sometimes life can be tough, and it's okay to feel sad. Would you like to talk about what's bothering you?", mood: "sad" },
        { text: "That sounds difficult. I'm here to listen if you need someone to talk to. Sometimes sharing can help lighten the load.", mood: "sad" }
      ],
      happy: [
        { text: "That's absolutely wonderful! I love hearing about good things happening. Your happiness is contagious - tell me more about what's making you smile!", mood: "excited" },
        { text: "That makes me so happy too! There's nothing better than sharing in someone's joy. What's the best part about it?", mood: "happy" }
      ],
      angry: [
        { text: "It sounds like you're really frustrated. That's completely understandable - we all have moments like that. Want to talk about what's bothering you?", mood: "thinking" },
        { text: "I can sense you're upset. Sometimes it helps to vent to someone who's just here to listen. I'm all ears!", mood: "neutral" }
      ],
      excited: [
        { text: "Your excitement is infectious! I love that energy. What's got you so pumped up? I want to hear all about it!", mood: "excited" },
        { text: "Wow, I can feel your enthusiasm! That's amazing. Share the excitement - what's happening?", mood: "excited" }
      ]
    },
    topics: {
      technology: [
        { text: "Technology is fascinating! I find it incredible how it connects people and opens up new possibilities. What aspect of tech interests you most?", mood: "excited" },
        { text: "I love talking about technology! It's amazing how fast things evolve. Are you into any particular tech trends or gadgets?", mood: "thinking" }
      ],
      creativity: [
        { text: "Creativity is one of my favorite topics! There's something magical about bringing new ideas to life. Are you working on any creative projects?", mood: "excited" },
        { text: "I'm always amazed by human creativity. Whether it's art, music, writing, or problem-solving - it's all fascinating to me. What sparks your creativity?", mood: "happy" }
      ],
      life: [
        { text: "Life is such an adventure, isn't it? Every day brings new experiences and opportunities to grow. What's been the highlight of your day so far?", mood: "happy" },
        { text: "I find life endlessly interesting - the ups, the downs, the unexpected moments. What's on your mind about life lately?", mood: "thinking" }
      ]
    },
    conversational: [
      { text: "That's really interesting! I hadn't thought about it that way before. What made you consider that perspective?", mood: "thinking" },
      { text: "I love how you put that! It really makes me think. Can you tell me more about your experience with that?", mood: "excited" },
      { text: "That's a great point! I'm curious - how do you usually approach situations like that?", mood: "happy" },
      { text: "Hmm, that's thought-provoking. I'm always learning from conversations like this. What's your take on it?", mood: "thinking" },
      { text: "I find that perspective fascinating! It's amazing how different people see things in unique ways. What led you to that conclusion?", mood: "neutral" }
    ]
  };

  addToContext(message: string) {
    this.context.push(message.toLowerCase());
    if (this.context.length > 10) {
      this.context.shift(); // Keep only last 10 messages for context
    }
  }

  analyzeMessage(message: string): { type: string; category?: string } {
    const lowerMessage = message.toLowerCase();
    const words = lowerMessage.split(' ');
    
    // Detect emotions
    const emotions = {
      sad: ['sad', 'depressed', 'down', 'upset', 'hurt', 'crying', 'terrible', 'awful', 'devastated'],
      happy: ['happy', 'great', 'wonderful', 'amazing', 'fantastic', 'excited', 'thrilled', 'joy', 'love'],
      angry: ['angry', 'mad', 'furious', 'annoyed', 'frustrated', 'irritated', 'pissed'],
      excited: ['excited', 'pumped', 'thrilled', 'amazing', 'awesome', 'incredible', 'fantastic']
    };

    // Detect topics
    const topics = {
      technology: ['technology', 'tech', 'computer', 'ai', 'robot', 'software', 'app', 'internet', 'digital'],
      creativity: ['art', 'music', 'creative', 'paint', 'draw', 'write', 'design', 'create', 'imagination'],
      life: ['life', 'living', 'experience', 'future', 'dreams', 'goals', 'family', 'friends', 'work']
    };

    // Check for emotions
    for (const [emotion, keywords] of Object.entries(emotions)) {
      if (keywords.some(keyword => lowerMessage.includes(keyword))) {
        return { type: 'emotion', category: emotion };
      }
    }

    // Check for topics
    for (const [topic, keywords] of Object.entries(topics)) {
      if (keywords.some(keyword => lowerMessage.includes(keyword))) {
        return { type: 'topic', category: topic };
      }
    }

    // Check for questions
    if (lowerMessage.includes('how are you') || lowerMessage.includes('how do you feel')) {
      return { type: 'question', category: 'how_are_you' };
    }
    if (lowerMessage.includes('what do you do') || lowerMessage.includes('what are you')) {
      return { type: 'question', category: 'what_do_you_do' };
    }
    if (lowerMessage.includes('who are you') || lowerMessage.includes('tell me about yourself')) {
      return { type: 'question', category: 'who_are_you' };
    }

    // Check for greetings
    if (words.some(word => ['hello', 'hi', 'hey', 'greetings'].includes(word))) {
      return { type: 'greeting' };
    }

    return { type: 'conversational' };
  }

  generateResponse(message: string) {
    this.addToContext(message);
    const analysis = this.analyzeMessage(message);
    
    let responsePool;
    
    switch (analysis.type) {
      case 'greeting':
        responsePool = this.responses.greeting;
        break;
      case 'question':
        if (analysis.category && analysis.category in this.responses.questions) {
          responsePool = this.responses.questions[analysis.category as keyof typeof this.responses.questions];
        } else {
          responsePool = this.responses.conversational;
        }
        break;
      case 'emotion':
        if (analysis.category && analysis.category in this.responses.emotions) {
          responsePool = this.responses.emotions[analysis.category as keyof typeof this.responses.emotions];
        } else {
          responsePool = this.responses.conversational;
        }
        break;
      case 'topic':
        if (analysis.category && analysis.category in this.responses.topics) {
          responsePool = this.responses.topics[analysis.category as keyof typeof this.responses.topics];
        } else {
          responsePool = this.responses.conversational;
        }
        break;
      default:
        responsePool = this.responses.conversational;
    }

    if (!responsePool || responsePool.length === 0) {
      responsePool = this.responses.conversational;
    }

    const response = responsePool[Math.floor(Math.random() * responsePool.length)];
    
    return {
      response: response.text,
      mood: response.mood
    };
  }
}

const localAI = new LocalAI();

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get default chat session
  app.get("/api/chat/session", async (req, res) => {
    try {
      const session = await storage.getDefaultChatSession();
      res.json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to get chat session" });
    }
  });

  // Get messages for a session
  app.get("/api/chat/:sessionId/messages", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      const messages = await storage.getMessagesBySession(sessionId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to get messages" });
    }
  });

  // Send a message and get AI response
  app.post("/api/chat/:sessionId/message", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      const { content } = insertMessageSchema.parse({
        ...req.body,
        sessionId,
        isUser: true,
      });

      // Save user message
      const userMessage = await storage.createMessage({
        sessionId,
        content,
        isUser: true,
        mood: "neutral"
      });

      let aiResponse;

      // Try OpenAI first if available
      if (process.env.OPENAI_API_KEY) {
        try {
          // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          const completion = await openai.chat.completions.create({
            model: "gpt-4o",
            messages: [
              {
                role: "system",
                content: `You are a friendly AI companion. Respond naturally to the user's message and also analyze the mood/emotion of your response. 
                Respond with JSON in this format: 
                {
                  "response": "your conversational response here",
                  "mood": "one of: happy, sad, excited, thinking, neutral"
                }`
              },
              {
                role: "user",
                content: content
              }
            ],
            response_format: { type: "json_object" },
          });

          aiResponse = JSON.parse(completion.choices[0].message.content || '{"response": "I apologize, but I encountered an error processing your message.", "mood": "neutral"}');
        } catch (openaiError) {
          // If OpenAI fails, fall back to alternatives
          console.log("OpenAI failed, trying alternatives:", (openaiError as any).message);
          aiResponse = null;
        }
      }

      // Try Hugging Face API if OpenAI failed or unavailable
      if (!aiResponse && process.env.HUGGINGFACE_API_KEY) {
        try {
          const hfResponse = await callHuggingFaceAPI(content);
          aiResponse = {
            response: hfResponse,
            mood: "neutral"
          };
        } catch (hfError) {
          console.log("Hugging Face failed, using fallback:", (hfError as any).message);
          aiResponse = null;
        }
      }

      // Use local AI if all else fails
      if (!aiResponse) {
        aiResponse = localAI.generateResponse(content);
      }

      // Save AI message
      const aiMessage = await storage.createMessage({
        sessionId,
        content: aiResponse.response,
        isUser: false,
        mood: aiResponse.mood || "happy"
      });

      res.json({
        userMessage,
        aiMessage,
        mood: aiResponse.mood || "happy"
      });
    } catch (error) {
      console.error("Chat error:", error);
      
      let errorContent = "I apologize, but I'm having trouble processing your message right now. Please try again.";
      let errorType = "Failed to process message";
      
      // Handle specific error types
      if ((error as any).status === 429 || (error as any).code === 'insufficient_quota') {
        errorContent = "I'd love to chat, but it looks like the OpenAI account needs billing credits added. Please check your OpenAI account's billing settings.";
        errorType = "OpenAI quota exceeded";
      } else if ((error as any).status === 401) {
        errorContent = "There's an issue with the API key configuration. Please check the OpenAI API key in settings.";
        errorType = "Authentication error";
      }
      
      // Save error response
      const errorMessage = await storage.createMessage({
        sessionId: parseInt(req.params.sessionId),
        content: errorContent,
        isUser: false,
        mood: "sad"
      });

      res.status(500).json({ 
        error: errorType,
        aiMessage: errorMessage,
        mood: "sad"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
