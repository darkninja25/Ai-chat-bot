import { useEffect, useState } from "react";
import { motion } from "framer-motion";

interface AIFaceProps {
  mood: string;
  isTalking: boolean;
}

export function AIFace({ mood, isTalking }: AIFaceProps) {
  const [isBlinking, setIsBlinking] = useState(false);
  const [mouthAnimation, setMouthAnimation] = useState(0);

  // Automatic blinking animation
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setIsBlinking(true);
      setTimeout(() => setIsBlinking(false), 150);
    }, 4000);

    return () => clearInterval(blinkInterval);
  }, []);

  // Enhanced mouth talking animation
  useEffect(() => {
    let animationInterval: NodeJS.Timeout;
    
    if (isTalking) {
      animationInterval = setInterval(() => {
        setMouthAnimation(prev => (prev + 1) % 4);
      }, 200);
    } else {
      setMouthAnimation(0);
    }

    return () => {
      if (animationInterval) {
        clearInterval(animationInterval);
      }
    };
  }, [isTalking]);

  const getMouthStyle = () => {
    if (isTalking) {
      // Different mouth shapes for talking animation
      const talkingShapes = [
        "rounded-full", // closed
        "rounded-lg w-8 h-4", // slightly open
        "rounded-md w-10 h-5", // more open
        "rounded-sm w-6 h-3", // different shape
      ];
      return talkingShapes[mouthAnimation];
    }
    
    switch (mood) {
      case "happy":
      case "excited":
        return "rounded-b-full border-t-0";
      case "sad":
        return "rounded-t-full border-b-0 translate-y-1";
      case "thinking":
      case "neutral":
      default:
        return "rounded-full";
    }
  };

  const getEyebrowStyle = () => {
    switch (mood) {
      case "excited":
        return "-translate-y-1";
      case "sad":
        return "translate-y-1";
      default:
        return "";
    }
  };

  const getCheekOpacity = () => {
    return mood === "excited" ? "opacity-100" : "opacity-0";
  };

  return (
    <motion.div 
      className="relative w-20 h-20 bg-white dark:bg-gray-800 rounded-full flex items-center justify-center shadow-lg"
      animate={mood === "thinking" ? { y: [-2, 2, -2] } : { y: 0 }}
      transition={{ duration: 1, repeat: mood === "thinking" ? Infinity : 0 }}
    >
      <div className="relative w-16 h-16">
        {/* Eyes */}
        <div className="absolute top-4 left-2 right-2 flex justify-between">
          <motion.div 
            className="w-3 h-3 bg-indigo-600 rounded-full"
            animate={isBlinking ? { scaleY: 0.1 } : { scaleY: 1 }}
            transition={{ duration: 0.1 }}
          />
          <motion.div 
            className="w-3 h-3 bg-indigo-600 rounded-full"
            animate={isBlinking ? { scaleY: 0.1 } : { scaleY: 1 }}
            transition={{ duration: 0.1 }}
          />
        </div>
        
        {/* Eyebrows */}
        <div className={`absolute top-2 left-2 right-2 flex justify-between transition-transform duration-300 ${getEyebrowStyle()}`}>
          <div className="w-4 h-1 bg-indigo-400 rounded-full"></div>
          <div className="w-4 h-1 bg-indigo-400 rounded-full"></div>
        </div>
        
        {/* Mouth */}
        <motion.div 
          className={`absolute bottom-4 left-1/2 transform -translate-x-1/2 w-6 h-3 border-2 border-indigo-600 transition-all duration-200 ${getMouthStyle()}`}
          animate={isTalking ? { 
            scaleY: [1, 1.2, 0.8, 1],
            scaleX: [1, 0.9, 1.1, 1]
          } : { scaleY: 1, scaleX: 1 }}
          transition={{ 
            duration: 0.4, 
            repeat: isTalking ? Infinity : 0,
            ease: "easeInOut"
          }}
        />
        
        {/* Cheeks (for excited state) */}
        <div className={`absolute top-6 left-0 right-0 flex justify-between transition-opacity duration-300 ${getCheekOpacity()}`}>
          <div className="w-2 h-2 bg-pink-300 rounded-full"></div>
          <div className="w-2 h-2 bg-pink-300 rounded-full"></div>
        </div>
      </div>
    </motion.div>
  );
}
