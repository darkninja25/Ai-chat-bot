import { motion } from "framer-motion";
import { User, Bot } from "lucide-react";
import type { ChatMessage } from "@/lib/openai";

interface ChatMessageProps {
  message: ChatMessage;
}

export function ChatMessageComponent({ message }: ChatMessageProps) {
  const isUser = message.isUser;
  
  const formatTime = (date?: Date) => {
    if (!date) return "Just now";
    return new Intl.DateTimeFormat('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    }).format(new Date(date));
  };

  return (
    <motion.div 
      className={`flex items-start space-x-3 ${isUser ? 'justify-end' : ''}`}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      {!isUser && (
        <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0">
          <Bot className="w-4 h-4 text-indigo-600" />
        </div>
      )}
      
      <div className={`max-w-md p-4 rounded-2xl ${
        isUser 
          ? 'bg-indigo-600 text-white rounded-tr-md' 
          : 'bg-indigo-50 rounded-tl-md'
      }`}>
        <p className={isUser ? 'text-white' : 'text-gray-800'}>
          {message.content}
        </p>
        <span className={`text-xs mt-2 block ${
          isUser ? 'text-indigo-200' : 'text-gray-500'
        }`}>
          {formatTime(message.createdAt)}
        </span>
      </div>
      
      {isUser && (
        <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center flex-shrink-0">
          <User className="w-4 h-4 text-white" />
        </div>
      )}
    </motion.div>
  );
}
