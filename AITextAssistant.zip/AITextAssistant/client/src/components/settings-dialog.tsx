import { useState } from "react";
import { Settings, Moon, Sun, Monitor } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export type Theme = "light" | "dark" | "system";

interface SettingsDialogProps {
  theme: Theme;
  onThemeChange: (theme: Theme) => void;
}

export function SettingsDialog({ theme, onThemeChange }: SettingsDialogProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="hover:text-indigo-600 transition-colors duration-200"
          title="Settings"
        >
          <Settings className="w-4 h-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
          <DialogDescription>
            Customize your AI companion experience.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          {/* Theme Settings */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Theme</Label>
            <RadioGroup
              value={theme}
              onValueChange={(value: Theme) => onThemeChange(value)}
              className="space-y-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="light" id="light" />
                <Label htmlFor="light" className="flex items-center space-x-2 cursor-pointer">
                  <Sun className="w-4 h-4" />
                  <span>Light</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="dark" id="dark" />
                <Label htmlFor="dark" className="flex items-center space-x-2 cursor-pointer">
                  <Moon className="w-4 h-4" />
                  <span>Dark</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="system" id="system" />
                <Label htmlFor="system" className="flex items-center space-x-2 cursor-pointer">
                  <Monitor className="w-4 h-4" />
                  <span>System</span>
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* API Status */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">API Status</Label>
            <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                <span className="text-sm">OpenAI API</span>
              </div>
              <span className="text-xs text-muted-foreground">Not configured</span>
            </div>
            <p className="text-xs text-muted-foreground">
              Add your OpenAI API key in environment settings to enable AI responses.
            </p>
          </div>

          {/* Face Animation Settings */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Animation</Label>
            <div className="flex items-center justify-between">
              <Label htmlFor="blinking" className="text-sm">Auto-blinking</Label>
              <Switch id="blinking" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="mouth-animation" className="text-sm">Mouth animation</Label>
              <Switch id="mouth-animation" defaultChecked />
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}