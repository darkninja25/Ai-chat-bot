// This file contains the OpenAI integration logic
// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user

export type AIMood = "happy" | "sad" | "excited" | "thinking" | "neutral" | "talking";

export interface AIResponse {
  response: string;
  mood: AIMood;
}

export interface ChatMessage {
  id: number;
  sessionId: number;
  content: string;
  isUser: boolean;
  mood?: string;
  createdAt?: Date;
}

export interface ChatResponse {
  userMessage: ChatMessage;
  aiMessage: ChatMessage;
  mood: AIMood;
}
