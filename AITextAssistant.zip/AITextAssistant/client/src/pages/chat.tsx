import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Send, Mic, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useTheme } from "@/hooks/use-theme";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { AIFace } from "@/components/ai-face";
import { ChatMessageComponent } from "@/components/chat-message";
import { TypingIndicator } from "@/components/typing-indicator";
import { SettingsDialog } from "@/components/settings-dialog";
import type { ChatMessage, ChatResponse, AIMood } from "@/lib/openai";

export default function Chat() {
  const [message, setMessage] = useState("");
  const [currentMood, setCurrentMood] = useState<AIMood>("happy");
  const [isTalking, setIsTalking] = useState(false);
  const [sessionId, setSessionId] = useState<number | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();

  // Get chat session
  const { data: session } = useQuery({
    queryKey: ["/api/chat/session"],
  });

  // Get messages for session
  const { data: messages = [], isLoading: messagesLoading } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat"],
    enabled: !!sessionId,
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!sessionId) throw new Error("No session available");
      
      const response = await apiRequest("POST", `/api/chat/${sessionId}/message`, {
        content
      });
      return response.json() as Promise<ChatResponse>;
    },
    onSuccess: (data) => {
      // Update mood based on AI response
      setCurrentMood(data.mood);
      setIsTalking(true);
      
      // Calculate speaking time based on message length (more realistic timing)
      const wordsPerMinute = 150; // Average speaking rate
      const words = data.aiMessage.content.split(' ').length;
      const speakingTimeMs = Math.max(2000, (words / wordsPerMinute) * 60 * 1000);
      
      // Stop talking animation after realistic speaking time
      setTimeout(() => {
        setIsTalking(false);
      }, speakingTimeMs);
      
      // Invalidate messages to refetch
      queryClient.invalidateQueries({ queryKey: ["/api/chat"] });
    },
    onError: (error) => {
      const errorMessage = error.message || "Failed to send message. Please try again.";
      
      if (errorMessage.includes("OpenAI API key not configured")) {
        toast({
          title: "API Key Required",
          description: "Please add your OpenAI API key in the environment settings to enable AI responses.",
          variant: "destructive",
        });
      } else if (errorMessage.includes("OpenAI quota exceeded")) {
        toast({
          title: "OpenAI Quota Exceeded",
          description: "Your OpenAI account needs billing credits. Please add credits to your OpenAI account.",
          variant: "destructive",
        });
      } else if (errorMessage.includes("Authentication error")) {
        toast({
          title: "Authentication Error",
          description: "There's an issue with your OpenAI API key. Please check your key configuration.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to send message. Please try again.",
          variant: "destructive",
        });
      }
      
      // Stop thinking animation on error
      setIsTalking(false);
      setCurrentMood("sad");
      
      // Invalidate queries to refresh the messages list even on error
      queryClient.invalidateQueries({ queryKey: ["/api/chat"] });
      
      console.error("Send message error:", error);
    }
  });

  // Auto-scroll to bottom
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, sendMessageMutation.isPending]);

  // Auto-focus on session load
  useEffect(() => {
    if (session && typeof session === 'object' && 'id' in session) {
      setSessionId((session as any).id);
    }
  }, [session]);

  const handleSendMessage = async () => {
    if (!message.trim() || sendMessageMutation.isPending) return;
    
    const messageToSend = message.trim();
    setMessage("");
    setCurrentMood("thinking");
    
    await sendMessageMutation.mutateAsync(messageToSend);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleClearChat = () => {
    // In a real app, you'd want to clear the chat history
    toast({
      title: "Chat cleared",
      description: "Your chat history has been cleared.",
    });
  };

  if (messagesLoading || !sessionId) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading chat...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col max-w-4xl mx-auto bg-background dark:bg-background shadow-xl overflow-hidden">
      {/* Header with AI Face */}
      <header className="bg-gradient-to-r from-indigo-500 to-purple-600 p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold">AI Companion</h1>
            <p className="text-indigo-100 text-sm">
              {sendMessageMutation.isPending ? "Thinking..." : "Ready to chat"}
            </p>
          </div>
          
          <AIFace mood={currentMood} isTalking={isTalking} />
        </div>
      </header>

      {/* Chat Messages Container */}
      <div 
        ref={chatContainerRef}
        className="flex-1 overflow-y-auto p-4 space-y-4"
        style={{ height: "calc(100vh - 200px)" }}
      >
        {messages.length === 0 ? (
          <motion.div 
            className="flex items-start space-x-3"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0">
              <div className="w-4 h-4 text-indigo-600">🤖</div>
            </div>
            <div className="bg-indigo-50 rounded-2xl rounded-tl-md p-4 max-w-md">
              <p className="text-gray-800">
                Hello! I'm your AI companion. I can see you're here to chat - I'm excited to get to know you! What's on your mind today?
              </p>
              <span className="text-xs text-gray-500 mt-2 block">Just now</span>
            </div>
          </motion.div>
        ) : (
          messages.length > 0 ? messages.map((msg: ChatMessage) => (
            <ChatMessageComponent key={msg.id} message={msg} />
          )) : null
        )}
        
        {sendMessageMutation.isPending && <TypingIndicator />}
      </div>

      {/* Message Input */}
      <div className="border-t border-border p-4 bg-background">
        <div className="flex items-center space-x-3">
          <div className="flex-1 relative">
            <Input
              type="text"
              placeholder="Type your message..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={sendMessageMutation.isPending}
              className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
            <Button
              variant="ghost"
              size="sm"
              className="absolute right-2 top-1/2 transform -translate-y-1/2 p-2 text-gray-400 hover:text-indigo-600"
            >
              <Mic className="w-4 h-4" />
            </Button>
          </div>
          <Button
            onClick={handleSendMessage}
            disabled={!message.trim() || sendMessageMutation.isPending}
            className="bg-indigo-600 hover:bg-indigo-700 text-white p-3 rounded-2xl transition-all duration-200 hover:scale-105 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>

        {/* Status Bar */}
        <div className="flex items-center justify-between mt-3 text-xs text-gray-500">
          <div className="flex items-center space-x-4">
            <span className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span>AI Online</span>
            </span>
            <span>~1s response time</span>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClearChat}
              className="hover:text-indigo-600 transition-colors duration-200"
              title="Clear chat"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
            <SettingsDialog theme={theme} onThemeChange={setTheme} />
          </div>
        </div>
      </div>
    </div>
  );
}
